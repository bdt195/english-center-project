<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Commend extends Model
{
    protected $table = 'commend';
}
